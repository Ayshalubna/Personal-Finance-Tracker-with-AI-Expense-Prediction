﻿def predict_expense(data):
    # Dummy function for now
    return f"Predicted expense for {data}"
